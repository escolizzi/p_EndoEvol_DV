#include "cash2.h"

void ObserverWrapper_main(int time,const TYPE2 **world, struct point ***neighbor);
void ObserverWrapper_init();
