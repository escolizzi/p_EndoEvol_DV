#include <vector>

#include "rna_fold_server_cash.hpp"

#ifndef FOLDWRAPPER_HPP
#define FOLDWRAPPER_HPP

class RNAFoldWrapper{
  std::vector<RNAFoldServerCash> carrier;

 public:
  RNAFoldWrapper()
}


#endif //FOLDWRAPPER_HPP
