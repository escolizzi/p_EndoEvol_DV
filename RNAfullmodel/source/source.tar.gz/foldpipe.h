void RNAOpen(char *target_structure);
int RNAClose(void);
float RNAFoldPipe(char *sequence,char *structure);
int RNADistancePipe(char *structure);
